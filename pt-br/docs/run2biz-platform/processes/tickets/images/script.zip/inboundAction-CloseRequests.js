var importNames = JavaImporter();
importNames.importPackage(Packages.java.util);
importNames.importPackage(Packages.java.lang);
importNames.importPackage(Packages.java.sql);
importNames.importPackage(Packages.br.com.centralit.citcorpore.negocio);
importNames.importPackage(Packages.br.com.centralit.citcorpore.integracao);
importNames.importPackage(Packages.br.com.centralit.citcorpore.bean);
importNames.importPackage(Packages.br.com.citframework.util);
importNames.importPackage(Packages.br.com.citframework.comparacao);
importNames.importPackage(Packages.br.com.citframework.integracao);
importNames.importPackage(Packages.br.com.centralit.bpm.integracao);
importNames.importPackage(Packages.br.com.centralit.bpm.dto);
importNames.importPackage(Packages.br.com.centralit.citcorpore.bpm.negocio);
importNames.importPackage(Packages.br.com.citframework.excecao);
var print = java.lang.System.out;

var execucaoFluxo = params.get("execucaoFluxo");
var jdbcEngine = new importNames.JdbcEngine(execucaoFluxo.getTransacao(),null);

montarSqlIdItemTrabalho = function() {
	var sql = new importNames.StringBuilder();
	sql.append("select it.iditemtrabalho ")
		.append("from bpm_itemtrabalhofluxo it join bpm_elementofluxo el on it.idelemento = el.idelemento ")
		.append("where it.idinstancia = ? and el.idtype = 2 ")
		.append("order by iditemtrabalho desc ")
		.append("limit 1");
	return sql.toString();
}

executaConsultaIdItemTrabalho = function(vIdInstancia){
    var parmsUtilizadosNoSQL = new importNames.ArrayList();
    parmsUtilizadosNoSQL.add(vIdInstancia);
    return jdbcEngine.execSQL(montarSqlIdItemTrabalho(), parmsUtilizadosNoSQL.toArray(), 0);
}

buscarIdItemTrabalho = function(vIdInstancia){
	var idItem = 0;
	var consultaItemTrabalho = executaConsultaIdItemTrabalho(vIdInstancia);
	if (consultaItemTrabalho!=null && !consultaItemTrabalho.isEmpty()){
		idItem = consultaItemTrabalho.get(0)[0];
	}
	return idItem;
}

montarSqlEncerraSolicitacao = function(){
	var sql = new importNames.StringBuilder();
	sql.append("update solicitacaoservico set ")
				.append("idstatus = 6,")
				.append("idtarefaencerramento = ?,")
				.append("tempoatendimentohh=0,")
				.append("tempoatendimentomm=1,")
				.append("tempoatrasohh = 0,")
				.append("tempoatrasomm = 0,")
				.append("idusuarioresponsavelatual = ?,")
				.append("datahorafim = CURRENT_TIMESTAMP ")
	   .append("where idsolicitacaoservico = ?");
	return sql.toString();
}

encerraSolicitacao = function(vIdSolicitacaoServico, vIdTarefa, vUsuarioResponsavel){
	var parmsUtilizadosNoSQL = new importNames.ArrayList();
	parmsUtilizadosNoSQL.add(vIdTarefa);
	parmsUtilizadosNoSQL.add(vUsuarioResponsavel);
	parmsUtilizadosNoSQL.add(vIdSolicitacaoServico);
	jdbcEngine.execUpdate(montarSqlEncerraSolicitacao(), parmsUtilizadosNoSQL.toArray());
}

montarSqlEncerraInstanciaFluxo = function(){
	var sql = new importNames.StringBuilder();
	sql.append("update bpm_instanciafluxo set idstatus = 4,")
									 .append("datahorafinalizacao = CURRENT_TIMESTAMP ")
	   .append("where idinstancia = ?");
	return sql.toString();
}

encerraInstanciaFluxo = function(vIdInstanciafluxo){
	var parmsUtilizadosNoSQL = new importNames.ArrayList();
	parmsUtilizadosNoSQL.add(vIdInstanciafluxo);
	jdbcEngine.execUpdate(montarSqlEncerraInstanciaFluxo(), parmsUtilizadosNoSQL.toArray());
}

montarSqlEncerraItemTrabalho = function(){
	var sql = new importNames.StringBuilder();
	sql.append("update bpm_itemtrabalhofluxo set idstatus = 7,")
										.append("idresponsavelatual = ?,")
										.append("datahorafinalizacao = CURRENT_TIMESTAMP ")
	   .append("where idinstancia = ? and idstatus in (1,2,3,4)");
	return sql.toString();
}

encerraItemTrabalho = function(vIdInstanciafluxo, vUsuarioResponsavel){
	var parmsUtilizadosNoSQL = new importNames.ArrayList();
	parmsUtilizadosNoSQL.add(vUsuarioResponsavel);
	parmsUtilizadosNoSQL.add(vIdInstanciafluxo);
	jdbcEngine.execUpdate(montarSqlEncerraItemTrabalho(), parmsUtilizadosNoSQL.toArray());
}

montarSqlBuscaDadosControleSLA = function(){
	var sql = new importNames.StringBuilder();
	sql.append("select csl.idcontrolesla, csl.datainicial, ss.idcalendario, CURRENT_TIMESTAMP ")
	.append("from solicitacaoservico ss join controlesla csl on ss.idsolicitacaoservico = csl.idsolicitacaoservico ")
	.append("where ss.idsolicitacaoservico = ? and (csl.datafinal is null)");
	return sql.toString();
}

executaConsultaBuscaDadosControleSLA = function(vIdSolicitacaoServico){
	var parmsUtilizadosNoSQL = new importNames.ArrayList();
	parmsUtilizadosNoSQL.add(vIdSolicitacaoServico);
	return jdbcEngine.execSQL(montarSqlBuscaDadosControleSLA(), parmsUtilizadosNoSQL.toArray(), 0);
}

montarSqlAtualizaControleSLA = function(){
	var sql = new importNames.StringBuilder();
	sql.append("update controlesla set idstatusfinal = 8, datafinal = ?, tempototal = ? ")
	.append("where idcontrolesla = ?");
	return sql.toString();
}

atualizarControleSLA = function(dataFinal, tempoTotal, idControleSLA){
	var parmsUtilizadosNoSQL = new importNames.ArrayList();
	parmsUtilizadosNoSQL.add(dataFinal);
	parmsUtilizadosNoSQL.add(tempoTotal);
	parmsUtilizadosNoSQL.add(idControleSLA);
	jdbcEngine.execUpdate(montarSqlAtualizaControleSLA(), parmsUtilizadosNoSQL.toArray());
}

calculaTempoTotalCalendario = function(idCalendario, dti, dtf){
	var calendarioServiceEjb = new importNames.CalendarioServiceEjb();
	if (dtf == null) {
		dtf = importNames.UtilDatas.getDataHoraAtual();
	}
	var calculoJornadaDTO = new importNames.CalculoJornadaDTO(idCalendario,dti,dtf);
	calculoJornadaDTO = calendarioServiceEjb.calculaTempoDecorridoHHMMSSPelaJornadaDeTrabalho(calculoJornadaDTO, tc);
	return (calculoJornadaDTO.getTempoDecorridoTotalEmSegundos()!=null)?calculoJornadaDTO.getTempoDecorridoTotalEmSegundos():0;
}

finalizarControleSLA = function(rControleSLA){
	var controleSlaServiceEjb = new importNames.ControleSlaServiceEjb();
	var tempoTotal = calculaTempoTotalCalendario(rControleSLA[2], rControleSLA[1], rControleSLA[3]);
	atualizarControleSLA(rControleSLA[3], tempoTotal, rControleSLA[0]);
}

encerrarControleSLA = function (vIdSolicitacaoServico){
	var listaControleSLAabertos = executaConsultaBuscaDadosControleSLA(vIdSolicitacaoServico);
	var rControleSLA = null;
	if((listaControleSLAabertos!=null)&&(listaControleSLAabertos.size()>0)){
		for (var itElementos = listaControleSLAabertos.iterator(); itElementos.hasNext();){
			rControleSLA = itElementos.next();
			if ((rControleSLA!=null) && (rControleSLA[0]!=null) && (rControleSLA[1]!=null)){
				finalizarControleSLA(rControleSLA);
			}
		}
	}
}

realizarEncerramentoSolicitacao = function (){
	try {
		var solicitacaoServicoDto = params.get("solicitacaoServico");
		var instanciafluxo = params.get("instanciafluxo");
		var vIdInstanciafluxo = instanciafluxo.getIdInstancia();
		var vIdSolicitacaoServico = solicitacaoServicoDto.getIdSolicitacaoServico();
		var vIdTarefa = buscarIdItemTrabalho(vIdInstanciafluxo);
		var vUsuarioResponsavel = solicitacaoServicoDto.getIdResponsavel();
		solicitacaoServicoDto.setIdStatus(6);
		encerraSolicitacao(vIdSolicitacaoServico, vIdTarefa, vUsuarioResponsavel);
		encerraInstanciaFluxo(vIdInstanciafluxo);
		encerraItemTrabalho(vIdInstanciafluxo, vUsuarioResponsavel);
		encerrarControleSLA(vIdSolicitacaoServico);
	} catch (err) {
        print.println("Problema ao finalizar solicitacao.\n");
		print.println(err);
    }
}

realizarEncerramentoSolicitacao();